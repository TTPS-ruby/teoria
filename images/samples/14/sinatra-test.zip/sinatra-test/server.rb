require 'bundler'
Bundler.require

get '/' do
      'hello world'
end
